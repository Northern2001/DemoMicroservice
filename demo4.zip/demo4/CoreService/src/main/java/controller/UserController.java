package controller;


import Enity.User;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {

    @GetMapping("/getListUser")
    public ResponseEntity<Object>  getListUser() {
        // this request is : http://localhost:8200/api/v1/user/getListUser
        List<User> users = List.of(
                new User("bacnguyen", "caobang", 21),
                new User("bacnguyen", "caobang", 21),
                new User("bacnguyen", "caobang", 21)
        );
       return new ResponseEntity<>(users, HttpStatus.ACCEPTED);
    }
}
